# DriverDrowsinessDetection
Web Application for Driver Drowsiness Detection
This is an application which detects the drowsiness of the diver while driving the vehicle.
### Libraries/Modules Used
- Tkinter
- Python 3.x
- OpenCV
  - Heart Rate Monitoring using Color Magnification
  - Haar Cascade classifiers
- Numpy
- Pyttsx3
- Winsound

